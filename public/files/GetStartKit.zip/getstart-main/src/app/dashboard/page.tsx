import Dashboard from '@/components/pages-components/Dashboard'
import React from 'react'

export default function page() {
  return (
    <Dashboard/>
  )
}
