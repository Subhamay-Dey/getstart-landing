import Login from '@/components/auth-components/Login'
import React from 'react'

export default function page() {
  return (
    <Login/>
  )
}
